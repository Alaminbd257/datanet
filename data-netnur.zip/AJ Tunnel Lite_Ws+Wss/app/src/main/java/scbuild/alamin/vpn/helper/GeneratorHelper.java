package scbuild.alamin.vpn.helper;

import androidx.appcompat.app.*;
import android.content.*;

import scbuild.alamin.vpn.view.*;

import com.scbuild.ajtunnel.lite.R;

public class GeneratorHelper implements RenzGenerator.OnDismissListener
{
	public interface GeneratorListener
	{
		void onCancel();
		void onGenerate(String payload);
	}
	private Context context;
	private GeneratorListener listener;
	private AlertDialog ab;
	public GeneratorHelper(Context context)
	{
		this.context = context;
	}
	public void setCancelListener(GeneratorListener GeneratorListener)
	{
		listener = GeneratorListener;
	}
	
	public void show()
	{
		RenzGenerator gen = new RenzGenerator(context);
		gen.setDismissListener(this);

	    ab = new AlertDialog.Builder(context).create();
		ab.setTitle(context.getString(R.string.app));
		ab.setView(gen);
		ab.setOnCancelListener(new DialogInterface.OnCancelListener()
			{

				@Override
				public void onCancel(DialogInterface p1)
				{
					listener.onCancel();
					// TODO: Implement this method
				}


			});
		ab.show();
	}

	@Override
	public void onDismiss(String payload)
	{
		listener.onGenerate(payload);
		ab.dismiss();
		// TODO: Implement this method
	}
}
