package scbuild.alamin.vpn.interfaces;

public interface OnByteCountListener
{
    void onByteCount(long bytes_in, long bytes_out);
}
