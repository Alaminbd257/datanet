package scbuild.alamin.vpn.adapter;
import android.content.*;
import android.graphics.Color;
import android.widget.*;
import java.util.*;
import android.view.*;
import scbuild.alamin.vpn.service.OpenVPNService.*;

import android.text.*;
import org.json.*;
import com.scbuild.ajtunnel.lite.R;

import android.view.animation.*;

public class Adapter
{
	public static class LogAdapter extends ArrayAdapter<LogMsg>
	{
		public LogAdapter(Context context, ArrayList<LogMsg> listLog)
		{
			super(context, R.layout.log_item, listLog);
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent)
		{
			View v = LayoutInflater.from(getContext()).inflate(R.layout.log_item, parent, false);
			TextView tv = (TextView)v.findViewById(R.id.log_item);
			LogMsg lm = getItem(position);
			tv.setText(Html.fromHtml(lm.line));
			// TODO: Implement this method
			return v;
		}
	}
	public static class ServerAdapter extends ArrayAdapter<String>
	{

		private ArrayList<String> listServer;

		private Context context;
		//private TextView category;
		public ServerAdapter(Context context, ArrayList<String> listServer)
		{
			super(context, R.layout.server_item, listServer);
			this.listServer = listServer;
			this.context = context;
		}

		@Override
		public String getItem(int position)
		{
			// TODO: Implement this method
			return super.getItem(position);
		}

		@Override
		public View getDropDownView(int position, View convertView, ViewGroup parent)
		{
			Animation anim = AnimationUtils.loadAnimation(getContext(), R.animator.jump_d);

			View v = MyView(position, convertView, parent);
			//v.startAnimation(anim);
			return v;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent)
		{
			// TODO: Implement this method
			return MyView(position, convertView, parent);
		}
		public View MyView(int position, View convertView, ViewGroup parent)
		{
			View v = LayoutInflater.from(getContext()).inflate(R.layout.server_item, parent, false);
			TextView tv = (TextView)v.findViewById(R.id.server_item_text);
			TextView tv2 = (TextView)v.findViewById(R.id.server_item_info);
			if(position != 0){
				tv2.setText("Ultimate");
				tv2.setTextColor(Color.MAGENTA);
			}
			ImageView iv = (ImageView)v.findViewById(R.id.server_item_icon);
			try {
				String name = getItem(position);

				tv.setText(name);
				name = name.toLowerCase();
				if (name.contains("singapore")) {
					setIcon(iv, R.drawable.sg);
				} else if (name.contains("united states")) {
					setIcon(iv, R.drawable.us);
				} else if (name.contains("united kingdom")) {
					setIcon(iv, R.drawable.uk);
				} else if (name.contains("metherland")) {
					setIcon(iv, R.drawable.nl);
				} else if (name.contains("germany")) {
					setIcon(iv,R.drawable.de);
				} else if (name.contains("india")) {
					setIcon(iv, R.drawable.in);
				} else if (name.contains("philippines")) {
					setIcon(iv, R.drawable.ph);
				} else if (name.contains("canada")) {
					setIcon(iv, R.drawable.ca);
				} else if (name.contains("korea")) {
					setIcon(iv, R.drawable.kr);
				} else if (name.contains("japan")) {
					setIcon(iv, R.drawable.jp);
				} else {
					setIcon(iv, R.drawable.ic_app_icon);
				}
			} catch (Exception e) {

			}
			// TODO: Implement this method
			return v;
		}
		
		private void setIcon(ImageView iv, int icon)
		{
			iv.setImageResource(icon);
		}
	}
	public static class NetworkAdapter extends ArrayAdapter<JSONObject>
	{

		private List<JSONObject> listNetwork;
		private Context context;
		public NetworkAdapter(Context context, List<JSONObject> listNetwork)
		{
			super(context, R.layout.network_item, listNetwork);
			this.listNetwork = listNetwork;
			this.context = context;
		}

		@Override
		public JSONObject getItem(int position)
		{
			// TODO: Implement this method
			return listNetwork.get(position);
		}

		@Override
		public int getCount()
		{
			// TODO: Implement this method
			return listNetwork.size();
		}
		@Override
		public View getView(int position, View convertView, ViewGroup parent)
		{
			// TODO: Implement this method
			return MyView(position, convertView, parent);
		}
		@Override
		public View getDropDownView(int position, View convertView, ViewGroup parent)
		{
			Animation anim = AnimationUtils.loadAnimation(getContext(), R.animator.jump_d);
			
			View v = MyView(position, convertView, parent);
			//v.startAnimation(anim);
			return v;
			// TODO: Implement this method
			
		}
		
		public View MyView(int position, View convertView, ViewGroup parent)
		{
			View v = LayoutInflater.from(context).inflate(R.layout.network_item, parent, false);
			TextView tv = (TextView)v.findViewById(R.id.network_item_title);
			//TextView tunnel_title = (TextView)v.findViewById(R.id.network_tunnel_title);
			ImageView iv = (ImageView)v.findViewById(R.id.network_item_icon);
			try {
				JSONObject js = getItem(position);
				String name = js.getString("Name");
				tv.setText(name.toUpperCase());
				name = name.toLowerCase(Locale.getDefault());
				
				/*if (js.getInt("TunnelType") == 0) {
					tunnel_title.setText("INJECT");
				} else {
					tunnel_title.setText("SSL");
				}*/
				name = name.toLowerCase();
				//tunnel_title.setText(js.getInt("TunnelType") == 0 ? "SSH/INJECT" : "SSH/SSL");
				if (name.contains("banglalink")) {
					setIcon(iv, R.drawable.banglalink);
				} else if (name.contains("dhiraagu")) {
					setIcon(iv, R.drawable.dhiraagu);
				} else if (name.contains("omantel")) {
					setIcon(iv, R.drawable.omantel);
				} else if (name.contains("starhub")) {
					setIcon(iv, R.drawable.starhub);
				} else if (name.contains("singtel")) {
					setIcon(iv, R.drawable.singtel);
				} else if (name.contains("vargin")) {
					setIcon(iv, R.drawable.vargin);
				} else if (name.contains("facebook")) {
					setIcon(iv, R.drawable.ic_facebook);
				} else if (name.contains("google")) {
					setIcon(iv, R.drawable.ic_google);
				} else if (name.contains("youtube")) {
					setIcon(iv, R.drawable.ic_youtube);
				} else if (name.contains("instagram")) {
					setIcon(iv, R.drawable.ic_instagram);
				} else if (name.contains("iflix")) {
					setIcon(iv, R.drawable.ic_iflix);
				} else if (name.contains("snapchat")) {
					setIcon(iv, R.drawable.ic_snapchat);
				} else if (name.contains("twitter")) {
					setIcon(iv, R.drawable.ic_twitter);
				} else if (name.contains("neflix")) {
					setIcon(iv, R.drawable.ic_netflix);
				} else if (name.contains("mobile legends")) {
					setIcon(iv, R.drawable.ic_ml);
				} else if (name.contains("du")) {
					setIcon(iv, R.drawable.ic_du);
				} else if(name.contains("etisalat")) {
					setIcon(iv, R.drawable.ic_eti);
				} else if (name.contains("wifi")) {
					setIcon(iv, R.drawable.ic_wifi);
				} else if (name.contains("whatsapp")) {
					setIcon(iv, R.drawable.ic_whatsapp);
				} else if (name.contains("tiktok")) {
					setIcon(iv, R.drawable.ic_tiktok);
				} else if (name.contains("viber")) {
					setIcon(iv, R.drawable.ic_viber);
				} else if(name.contains("airtel")) {
					setIcon(iv, R.drawable.ic_airtel);
				} else if(name.contains("jawwy")) {
					setIcon(iv, R.drawable.ic_jawwy);
				} else if(name.contains("digi")) {
					setIcon(iv, R.drawable.ic_digi);
				}  else if(name.contains("mobily")) {
					setIcon(iv, R.drawable.ic_mobily);
				}  else if(name.contains("airtel")) {
					setIcon(iv, R.drawable.ic_airtel);
				}  else if(name.contains("pubg")) {
					setIcon(iv, R.drawable.ic_pubg);
				}  else if(name.contains("stc")) {
					setIcon(iv, R.drawable.ic_stc);
				}  else if(name.contains("skype")) {
					setIcon(iv, R.drawable.ic_skype);
				}  else if(name.contains("telegram")) {
					setIcon(iv, R.drawable.ic_telegram);
				}  else if(name.contains("vivobee")) {
					setIcon(iv, R.drawable.ic_vivobee);
				}  else if(name.contains("zain")) {
					setIcon(iv, R.drawable.ic_zain);
				}  else if(name.contains("zain free")) {
					setIcon(iv, R.drawable.zain_free);
				}  else if(name.contains("ooredoo")) {
					setIcon(iv, R.drawable.ic_ooreedo);
				}  else if(name.contains("viva")) {
					setIcon(iv, R.drawable.ic_viva);
				}  else if(name.contains("progresif")) {
					setIcon(iv, R.drawable.ic_progresif);
				}  else if(name.contains("jio")) {
					setIcon(iv, R.drawable.ic_jio);
				}  else if(name.contains("lebara")) {
					setIcon(iv, R.drawable.ic_lebara);
				}  else if(name.contains("vodafone")) {
					setIcon(iv, R.drawable.ic_vodafone);
				}  else if(name.contains("mobily")) {
					setIcon(iv, R.drawable.ic_mobily);
				} else {
					setIcon(iv, R.drawable.ic_app_icon);
				}
				//setAnimation(v, position);
			} catch (Exception e) {
				Toast.makeText(getContext(), "SpinnerView - " + e.getMessage(), 1).show();
			}

			// TODO: Implement this method
			return v;
		}
		public void setIcon(ImageView iv, int icon)
		{
			iv.setImageResource(icon);
		}
		
	}
}
