package scbuild.alamin.vpn.utils;
import java.net.*;

import scbuild.alamin.vpn.service.*;

public class VPNUtil
{

    private static VPNUtil.VPNProtectListener Listener;
    private static OpenVPNService mService;
    private static String CONFIG_PASS = "@abc123";
    public interface VPNProtectListener
    {
        boolean protectSocket(Socket socket);
    }
    public static void setVPNProtectListener(VPNProtectListener VPNProtectListener)
    {
        Listener = VPNProtectListener;
    }
    public static boolean isProtected(Socket socket)
    {
        return Listener != null ? Listener.protectSocket(socket) : false;
    }
    public static void setVPNService(OpenVPNService service)
    {
        mService = service;
    }
    public static OpenVPNService getService()
    {
        return mService;
    }
    public static String decrypt (String str)
    {
        return Utils.Parser.parseToString(str.replace(" ", "").replace("\n", ""));
    }
    public static String encrypt(String string)
    {
        return Utils.Parser.parse(string);
    }
}
