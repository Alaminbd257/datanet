package net.openvpn.openvpn;

public class SWIGTYPE_p_std__vectorT_std__string_t {
    private long swigCPtr;

    protected SWIGTYPE_p_std__vectorT_std__string_t(long cPtr, boolean futureUse) {
        this.swigCPtr = cPtr;
    }

    protected SWIGTYPE_p_std__vectorT_std__string_t() {
        this.swigCPtr = 0;
    }

    protected static long getCPtr(SWIGTYPE_p_std__vectorT_std__string_t obj) {
        return obj == null ? 0 : obj.swigCPtr;
    }
}
