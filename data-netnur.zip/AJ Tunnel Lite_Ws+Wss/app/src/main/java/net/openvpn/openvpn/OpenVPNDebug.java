package net.openvpn.openvpn;

public class OpenVPNDebug {
    OpenVPNDebug() {
    }

    public static String pw_repl(String user, String pw) {
        return pw;
    }
}
